import React from 'react'
import { Provider } from 'mobx-react'
import { membersStore } from './src/stores/MembersStore'
import { searchStore } from './src/stores/SearchStore'

export default function Stores({ element }) {
  return (
    <Provider
      membersStore={membersStore}
      searchStore={searchStore}
    >{element}</Provider>
  )
}
