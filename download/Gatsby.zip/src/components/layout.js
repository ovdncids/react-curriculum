import React from 'react'
import { Link } from 'gatsby'

export default function Layout({ children }) {
  return (
    <div>
      <header>
        <h1>React study</h1>
      </header>
      <hr />
      <div className="container">
        <nav className="nav">
          <ul>
            <li><h2><Link to="/" activeClassName='active'>Members</Link></h2></li>
            <li><h2><Link to="/search" activeClassName='active'>Search</Link></h2></li>
          </ul>
        </nav>
        <hr />
        <section className="contents">
          {children}
        </section>
        <hr />
      </div>
      <footer>Copyright</footer>
    </div>
  )
}
