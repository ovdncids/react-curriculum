import React from 'react'

export default function Page404() {
  return (
    <div>404 Page</div>
  )
}
