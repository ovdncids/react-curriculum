import InnerWidth from './components/InnerWidth.js';

function App() {
  return (
    <InnerWidth></InnerWidth>
  );
}

export default App;
