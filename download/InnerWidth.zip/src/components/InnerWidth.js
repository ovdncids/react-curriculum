import { useState, useEffect } from 'react';

function InnerWidth() {
  const [ innerWidth, setInnerWidth ] = useState(window.innerWidth);
  useEffect(() => {
    const resize = function() {
      setInnerWidth(window.innerWidth);
    }
    window.addEventListener('resize', resize);
    return () => {
      window.removeEventListener('resize', resize);
    }
  }, []);
  return (
    <div>{innerWidth}</div>
  )
}

export default InnerWidth;
