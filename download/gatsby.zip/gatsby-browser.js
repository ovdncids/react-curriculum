import provideStores from './provide-stores'

export const wrapRootElement = provideStores
