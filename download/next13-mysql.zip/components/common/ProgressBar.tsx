import {useState, useEffect} from "react"
import {useRouter} from "next/router"
import Box from "@mui/material/Box"
import LinearProgress from "@mui/material/LinearProgress"

const ProgressBar = () => {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  useEffect(() => {
    router.events.on("routeChangeStart", () => setOpen(true))
    router.events.on("routeChangeComplete", () => setOpen(false))
    router.events.on("routeChangeError", () => setOpen(false))
  }, [router.events])
  return (
    <Box sx={{width: "100%", minWidth: "1942px", position: "absolute"}}>
      {open && <LinearProgress />}
    </Box>
  )
}

export default ProgressBar
