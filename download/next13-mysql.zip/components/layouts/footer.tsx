const Footer = () => {
  return <footer>Copyright</footer>
}

export default Footer
