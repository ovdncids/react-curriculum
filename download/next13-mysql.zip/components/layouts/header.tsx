const Header = () => {
  return (
    <header>
      <h1>Next study</h1>
    </header>
  )
}

export default Header
