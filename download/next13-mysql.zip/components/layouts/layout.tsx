import Footer from "./footer"
import Header from "./header"
import Nav from "./nav"

const Layout = ({children}: {children: React.ReactNode}) => {
  return (
    <div>
      <Header></Header>
      <hr />
      <div className="container">
        <Nav></Nav>
        <hr />
        <section className="contents">{children}</section>
        <hr />
      </div>
      <Footer></Footer>
    </div>
  )
}

export default Layout
