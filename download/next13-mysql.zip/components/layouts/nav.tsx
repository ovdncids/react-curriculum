import ActiveLink from "../common/ActiveLink"

const Nav = () => {
  return (
    <nav className="nav">
      <ul>
        <li>
          <h2>
            <ActiveLink activeClassName="active" href="/members">
              <a>Members</a>
            </ActiveLink>
          </h2>
        </li>
        <li>
          <h2>
            <ActiveLink activeClassName="active" href="/search">
              <a>Search</a>
            </ActiveLink>
          </h2>
        </li>
      </ul>
    </nav>
  )
}

export default Nav
