import type mysql from "mysql"

interface mysqlPool extends mysql.Pool {
  error: Function
}

export const {db} = global as unknown as {db: mysqlPool}
export default db
