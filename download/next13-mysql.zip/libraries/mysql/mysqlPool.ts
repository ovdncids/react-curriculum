import type mysql from "mysql"

interface MysqlPool extends mysql.Pool {
  error: Function
}

export const {mysqlPool: db} = global as unknown as {mysqlPool: MysqlPool}
export default db
