/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true
}

module.exports = nextConfig

// MySQL
const mysql = require("mysql")

const db = mysql.createPool({
  host: "localhost",
  user: "semin@localhost",
  password: "",
  database: "test"
})

db.query("select 123 as abc", null, function (error, rows) {
  console.error(error)
  console.log(rows)
})

const dbError = function (req, res, error) {
  console.error("Start: SQL error")
  console.error(error.sql)
  console.error("End: SQL error")
  // error.sql = undefined;
  res.status(500).send(error)
  return false
}

global.db = db
global.dbError = dbError
