/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true
}

module.exports = nextConfig

// MySQL
global.db = require("./libraries/mysql/mysqlConnector")
