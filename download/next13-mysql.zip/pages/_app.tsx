import "../styles/globals.scss"
import type {AppProps} from "next/app"
import ProgressBar from "../components/common/ProgressBar"

export default function App({Component, pageProps}: AppProps) {
  return (
    <>
      <ProgressBar />
      <Component {...pageProps} />
    </>
  )
}
