import type {NextApiRequest, NextApiResponse} from "next"
import type {Member} from "../../../types/members"
import db from "../../../libraries/mysql/mysqlPool"

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<Member[]>
) {
  const member_pk = Number(req.query.member_pk as string)
  if (req.method === "DELETE") {
    const sql = "delete from members where member_pk = ?"
    db.query(sql, [member_pk], function (error, rows) {
      if (error) return db.error(req, res, error)
      console.log("Done members delete", rows)
      res.status(200).json(rows)
    })
  } else if (req.method === "PATCH") {
    const sql = "update members set name = ?, age = ? where member_pk = ?"
    db.query(
      sql,
      [req.body.name, req.body.age, member_pk],
      function (error, rows) {
        if (error) return db.error(req, res, error)
        console.log("Done members update", rows)
        res.status(200).json(rows)
      }
    )
  }
}
