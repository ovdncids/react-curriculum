import type {NextApiRequest, NextApiResponse} from "next"
import type {Member} from "../../../types/members"
import db from "../../../libraries/mysql/mysqlPool"

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<Member[] | String>
) {
  if (req.method === "GET") {
    const sql = "select * from members"
    db.query(sql, null, function (error, rows) {
      if (error) return db.error(req, res, error)
      console.log("Done members read", rows)
      res.status(200).json(rows)
    })
  } else if (req.method === "POST") {
    const sql = "insert into members(name, age) values (?, ?)"
    db.query(sql, [req.body.name, req.body.age], function (error, rows) {
      if (error) return db.error(req, res, error)
      console.log("Done members create", rows)
      res.status(200).json(rows)
    })
  }
}
