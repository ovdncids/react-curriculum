// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type {NextApiRequest, NextApiResponse} from "next"
import type {Member} from "../../types/members"

const {members: _members} = global as unknown as {members: Member[]}

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<Member[]>
) {
  const members: Member[] = []
  const q = req.query.q as string
  _members.forEach((member) => {
    if (!q || member.name.includes(q)) {
      members.push(member)
    }
  })
  res.status(200).json(members)
}
