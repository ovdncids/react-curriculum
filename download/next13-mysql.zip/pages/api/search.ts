import type {NextApiRequest, NextApiResponse} from "next"
import type {Member} from "../../types/members"
import db from "../../libraries/mysql/mysqlPool"

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<Member[] | String>
) {
  const q = req.query.q || ""
  const sql = `select * from members where ? = '' or name like ?`
  db.query(sql, [q, `%${q}%`], function (error, rows) {
    if (error) return db.error(req, res, error)
    console.log("Done members search", rows)
    res.status(200).json(rows)
  })
}
