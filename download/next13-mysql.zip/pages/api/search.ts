import type {NextApiRequest, NextApiResponse} from "next"
import type {Member} from "../../types/members"
import type mysql from "mysql"

const {db, dbError} = global as unknown as {db: mysql.Pool; dbError: Function}

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<Member[] | String>
) {
  const q = req.query.q || ""
  const sql = `select * from members where ? = '' || name like ?`
  db.query(sql, [q, `%${q}%`], function (error, rows) {
    if (error) return dbError(req, res, error)
    console.log("Done members search", rows)
    res.status(200).json(rows)
  })
}
