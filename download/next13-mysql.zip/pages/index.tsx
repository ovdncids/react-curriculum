const Home = () => {
  return <></>
}

export const getServerSideProps = () => {
  return {
    redirect: {
      destination: "/members"
    }
  }
}

export default Home
