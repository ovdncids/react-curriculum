import {useEffect, useState} from "react"
import {useRouter} from "next/router"
import Layout from "../components/layouts/layout"
import type {Member} from "../types/members"
import axios from "axios"

const Members = ({members: _members}: {members: Member[]}) => {
  const router = useRouter()
  const [member, setMember] = useState({
    name: "",
    age: ""
  })
  const [__members, setMembers] = useState(_members)
  const members: Member[] = JSON.parse(JSON.stringify(__members))
  const membersCreate = async () => {
    await axios.post("http://localhost:3000/api/members", member)
    router.push({pathname: "/members"})
  }
  const membersDelete = async (member_pk: number) => {
    await axios.delete(`http://localhost:3000/api/members/${member_pk}`)
    router.push({pathname: "/members"})
  }
  const membersUpdate = async (member_pk: number, member: Member) => {
    await axios.patch(`http://localhost:3000/api/members/${member_pk}`, member)
    router.push({pathname: "/members"})
  }
  useEffect(() => {
    setMembers(_members)
  }, [_members])
  return (
    <Layout>
      <div>
        <h3>Members</h3>
        <hr className="d-block" />
        <div>
          <h4>Read</h4>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Age</th>
                <th>Modify</th>
              </tr>
            </thead>
            <tbody>
              {members.map((member, index) => (
                <tr key={index}>
                  <td>
                    <input
                      type="text"
                      placeholder="Name"
                      value={member.name}
                      onChange={(event) => {
                        member.name = event.target.value
                        setMembers(members)
                      }}
                    />
                  </td>
                  <td>
                    <input
                      type="text"
                      placeholder="Age"
                      value={member.age}
                      onChange={(event) => {
                        member.age = event.target.value
                        setMembers(members)
                      }}
                    />
                  </td>
                  <td>
                    <button
                      onClick={() => membersUpdate(member.member_pk, member)}
                    >
                      Update
                    </button>
                    <button onClick={() => membersDelete(member.member_pk)}>
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <hr className="d-block" />
        <div>
          <h4>Create</h4>
          <input
            type="text"
            placeholder="Name"
            value={member.name}
            onChange={(event) => {
              setMember({...member, name: event.target.value})
            }}
          />
          <input
            type="text"
            placeholder="Age"
            value={member.age}
            onChange={(event) => {
              setMember({...member, age: event.target.value})
            }}
          />
          <button onClick={() => membersCreate()}>Create</button>
        </div>
      </div>
    </Layout>
  )
}

export const getServerSideProps = async () => {
  const response = await axios.get("http://localhost:3000/api/members")
  return {
    props: {
      members: response.data
    }
  }
}

export default Members
