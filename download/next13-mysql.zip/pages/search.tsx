import React, {useState, useEffect} from "react"
import {NextPageContext} from "next"
import {useRouter} from "next/router"
import Layout from "../components/layouts/layout"
import type {Member} from "../types/members"
import axios from "axios"

const Search = ({members, q: _q}: {members: Member[]; q: string}) => {
  const router = useRouter()
  const [q, setQ] = useState(_q)
  const searchRead = (event: React.SyntheticEvent) => {
    event.preventDefault()
    router.push({query: {q}})
  }
  useEffect(() => {
    setQ(_q)
  }, [_q])
  return (
    <Layout>
      <div>
        <h3>Search</h3>
        <hr className="d-block" />
        <div>
          <form onSubmit={searchRead}>
            <input
              type="text"
              placeholder="Search"
              value={q}
              onChange={(event) => setQ(event.target.value)}
            />
            <button>Search</button>
          </form>
        </div>
        <hr className="d-block" />
        <div>
          <table className="table-search">
            <thead>
              <tr>
                <th>Name</th>
                <th>Age</th>
              </tr>
            </thead>
            <tbody>
              {members.map((member, index) => (
                <tr key={index}>
                  <td>{member.name}</td>
                  <td>{member.age}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Layout>
  )
}

export const getServerSideProps = async (context: NextPageContext) => {
  const q = context.query.q || ""
  const response = await axios.get(`http://localhost:3000/api/search?q=${q}`)
  return {
    props: {
      members: response.data,
      q
    }
  }
}

export default Search
