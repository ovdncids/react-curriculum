export type Member = {
  member_pk: number
  name: string
  age: number | string
}
