const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const fileUpload = require('express-fileupload');
const member = require('./routes/member');
const search = require('./routes/search');
const app = express();
const YAML = require('yamljs');
const swaggerDocument = YAML.load(path.join(__dirname, './swagger.yaml'));
const swaggerUi = require('swagger-ui-express');
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// Start: Request, Response Settings
app.use((req, res, next) => {
  // res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'Authorization, X-Access-Token, X-Requested-With, Accept, Content-Type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  next();
});
// End: Request, Response Settings

// Start: set cross-origin, bodyParser
app.use(bodyParser.json({limit: '1mb'}));
// app.use(bodyParser.urlencoded({extended: false}));
// End: set cross-origin, bodyParser

// Start: express-fileupload
app.use(fileUpload());
// End: express-fileupload

// Start: set public
app.use(express.static(path.join(__dirname, 'public')));
app.get('/', function (req, res) {
  res.render('public/index.html')
});
// End: set public

app.use('/api/v1/member', member);
app.use('/api/v1/search', search);

// Start: start server
const port = 3100;
app.listen(port, function () {
  console.log('Express server listening on port ' + port);
});
// End: start server
