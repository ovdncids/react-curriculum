const express = require('express');
const bodyParser = require('body-parser');
const fileUpload = require('express-fileupload');
const member = require('./routes/member');
const app = express();

// Start: Request, Response Settings
app.use((req, res, next) => {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'Authorization, X-Access-Token, X-Requested-With, Accept, Content-Type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  next();
});
// End: Request, Response Settings

// Start: set cross-origin, bodyParser
app.use(bodyParser.json({limit: '1mb'}));
// app.use(bodyParser.urlencoded({extended: false}));
// End: set cross-origin, bodyParser

// Start: express-fileupload
app.use(fileUpload());
// End: express-fileupload

app.use('/api/v1/member', member);

// Start: start server
const port = 3100;
app.listen(port, function () {
  console.log('Express server listening on port ' + port);
});
// End: start server
