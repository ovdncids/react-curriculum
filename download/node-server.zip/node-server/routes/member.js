const express = require('express');
const router = express.Router();
const members = [
  {
    name: '홍길동',
    age: '39'
  }
]

router.post('/', function (req, res) {
  members[members.length] = req.body;
  console.log(members);
  res.status(200).send({
    message: 'OK'
  });
});

module.exports = router;
