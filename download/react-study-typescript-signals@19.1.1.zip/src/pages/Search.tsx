import { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { signal, useComputed } from '@preact/signals-react';
import { usersState } from 'stores/usersStore';
import { searchActions } from 'stores/searchStore';

const stateQ = signal('');

function SearchBar() {
  const navigate = useNavigate();
  console.log('SearchBar', stateQ.value);
  return (
    <div>
      <form onSubmit={(event) => {
        event.preventDefault();
        navigate('/search?q=' + stateQ.value);
      }}>
        {useComputed(() => {
          console.log('SearchBar.stateQ', stateQ.value);
          return (
            <input
              type="text" placeholder="Search"
              value={stateQ.value}
              onChange={event => {stateQ.value = event.target.value}}
            />
          );
        })}
        <button>Search</button>
      </form>
    </div>
  );
}

function Search() {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const q = searchParams.get('q') || '';
  useEffect(() => {
    console.warn('useEffect', q, stateQ.value);
    stateQ.value = q;
    searchActions.searchRead(q);
  }, [q]);
  console.log('Search', q, usersState.users.value);
  return (
    <div>
      <h3>Search</h3>
      <hr className="d-block" />
      <SearchBar />
      <hr className="d-block" />
      <div>
        <table className="table-search">
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
            </tr>
          </thead>
          <tbody>
            {useComputed(() => {
              console.log('Search.users', usersState.users.value);
              return usersState.users.value.map((user, index) => (
                <tr key={index}>
                  <td>{user.name}</td>
                  <td>{user.age}</td>
                </tr>
              ));
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Search;
