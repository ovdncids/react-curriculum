import { useEffect } from 'react';
import { useComputed } from '@preact/signals-react';
import { usersState, usersActions } from 'stores/usersStore';

function Users() {
  console.log('Users', usersState.users.value, usersState.user.value);
  useEffect(() => {
    usersActions.usersRead();
  }, []);
  return (
    <div>
      <h3>Users</h3>
      <hr className="d-block" />
      <div>
        <h4>Read</h4>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
              <th>Modify</th>
            </tr>
          </thead>
          <tbody>
            {useComputed(() => {
              console.log('Read', usersState.users.value);
              return usersState.users.value.map((user, index) => (
                <tr key={index}>
                  <td>
                    <input
                      type="text" placeholder="Name" value={user.name}
                      onChange={(event) => {
                        const users = [...usersState.users.value];
                        users[index].name = event.target.value;
                        usersState.users.value = users;
                      }}
                    />
                  </td>
                  <td>
                    <input
                      type="text" placeholder="Age" value={user.age}
                      onChange={(event) => {
                        const users = [...usersState.users.value];
                        users[index].age = event.target.value;
                        usersState.users.value = users;
                      }}
                    />
                  </td>
                  <td>
                    <button onClick={() => {
                      usersActions.usersUpdate(index, user);
                    }}>Update</button>
                    <button onClick={() => {
                      usersActions.usersDelete(index);
                    }}>Delete</button>
                  </td>
                </tr>
              ));
            })}
          </tbody>
        </table>
      </div>
      <hr className="d-block" />
      <div>
        <h4>Create</h4>
        {useComputed(() => {
          console.log('Create.name', usersState.user.value.name);
          return (
            <input
              type="text" placeholder="Name" value={usersState.user.value.name}
              onChange={(event) => {
                usersState.user.value = {
                  ...usersState.user.value,
                  name: event.target.value
                }
              }}
            />
          );
        })}
        {useComputed(() => {
          console.log('Create.age', usersState.user.value.age);
          return (
            <input
              type="text" placeholder="Age" value={usersState.user.value.age}
              onChange={(event) => {
                usersState.user.value = {
                  ...usersState.user.value,
                  age: event.target.value
                }
              }}
            />
          );
        })}
        <button onClick={() => {
          usersActions.usersCreate(usersState.user);
        }}>Create</button>
      </div>
    </div>
  );
}

export default Users;
