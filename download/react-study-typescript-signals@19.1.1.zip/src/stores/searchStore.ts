import axios from 'axios';
import { usersState } from './usersStore';

export const searchActions = {
  searchRead: async (q: string) => {
    const response = await axios.get('http://localhost:3100/api/v1/search?q=' + q);
    console.log('Done searchRead', response);
    usersState.users.value = response.data.users;
  }
};
