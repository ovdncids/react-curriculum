import Header from './components/layout/Header'
import Nav from './components/layout/Nav'
import Footer from './components/layout/Footer'
import { Outlet } from 'react-router-dom'

function App() {
  return (
    <div>
      <Header />
      <hr />
      <div className="container">
        <Nav />
        <hr />
        <section className="contents">
          <Outlet />
        </section>
        <hr />
      </div>
      <Footer />
    </div>
  )
}

export default App
