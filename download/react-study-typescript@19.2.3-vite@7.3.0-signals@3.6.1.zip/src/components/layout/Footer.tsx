function Footer(props: any) {
  console.log(props)
  return (
    <footer>Copyright</footer>
  )
}

export default Footer
