// import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.scss'
import App from './App.tsx'
import { createBrowserRouter, Navigate, RouterProvider } from 'react-router-dom'
import Users from './pages/Users'
import Search from './pages/Search'

const router = createBrowserRouter(
  [
    {
      path: '/',
      element: <App />,
      children: [
        { path: '/users', element: <Users /> },
        { path: '/search', element: <Search /> },
        {
          index: true,
          element: <Navigate replace to="/users" />
        }
      ]
    }
  ]
)

createRoot(document.getElementById('root')!).render(
  // <StrictMode>
    <RouterProvider router={router} />
  // </StrictMode>
)
