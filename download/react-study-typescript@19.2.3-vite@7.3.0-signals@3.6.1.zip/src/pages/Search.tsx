import { useEffect } from 'react'
import { useComputed, useSignal } from '@preact/signals-react'
import { usersState } from '@/stores/usersStore'
import { searchActions } from '@/stores/searchStore'
import { useNavigate, useLocation } from 'react-router-dom'

function SearchBar(props: {q: string}) {
  const navigate = useNavigate()
  const q = useSignal(props.q)
  useEffect(() => {
    console.warn('SearchBar.useEffect', props.q, q.value)
    q.value = props.q
  }, [q, props.q])
  console.log('SearchBar', props.q, q.value)
  return (
    <div>
      <form onSubmit={(event) => {
        event.preventDefault()
        navigate('/search?q=' + q.value)
      }}>
        {useComputed(() => {
          console.log('SearchBar.q', q.value)
          return (
            <input
              type="text" placeholder="Search"
              value={q.value}
              onChange={event => {q.value = event.target.value}}
            />
          )
        })}
        <button>Search</button>
      </form>
    </div>
  )
}

function Search() {
  const location = useLocation()
  const searchParams = new URLSearchParams(location.search)
  const q = searchParams.get('q') || ''
  searchActions.searchRead(q)
  console.log('Search', q, usersState.users.value)
  return (
    <div>
      <h3>Search</h3>
      <hr className="d-block" />
      <SearchBar q={q} />
      <hr className="d-block" />
      <div>
        <table className="table-search">
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
            </tr>
          </thead>
          <tbody>
            {useComputed(() => {
              console.log('Search.users', usersState.users.value)
              return usersState.users.value.map((user, index) => (
                <tr key={index}>
                  <td>{user.name}</td>
                  <td>{user.age}</td>
                </tr>
              ))
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default Search
