import { Signal, signal } from '@preact/signals-react'
import axios from 'axios'

interface User {
  name: string
  age: string | number
}

export const usersState = {
  users: signal<User[]>([]),
  user: signal<User>({
    name: '',
    age: ''
  })
}

export const usersActions = {
  usersCreate: async (user: Signal<User>) => {
    const response = await axios.post('/api/v1/users', user.value)
    console.log('Done usersCreate', response)
    usersActions.usersRead()
  },
  usersRead: async () => {
    const response = await axios.get('/api/v1/users')
    console.log('Done usersRead', response)
    usersState.users.value = response.data.users
  },
  usersDelete: async (index: number) => {
    const response = await axios.delete('/api/v1/users/' + index)
    console.log('Done usersDelete', response)
    usersActions.usersRead()
  },
  usersUpdate: async (index: number, user: User) => {
    const response = await axios.patch('/api/v1/users/' + index, user)
    console.log('Done usersUpdate', response)
    usersActions.usersRead()
  }
}
