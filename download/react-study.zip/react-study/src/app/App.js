import React, { Component } from 'react';
import { BrowserRouter, Switch, Route } from 'react-router-dom';
import Header from './components/Header';
import Nav from './components/Nav';
import Footer from './components/Footer';
import CRUD from './components/contents/CRUD';
import Search from './components/contents/Search';

class App extends Component {
  render() {
    return (
      <BrowserRouter>
        <div>
          <Header />
          <hr />
          <div className="container">
            <Nav />
            <hr />
            <div className="contents">
              <section>
                <Switch>
                  <Route exact={true} path="/search" component={Search}/>
                  <Route component={CRUD}/>
                </Switch>
              </section>
            </div>
            <hr />
          </div>
          <Footer />
        </div>
      </BrowserRouter>
    );
  }
}

export default App;
