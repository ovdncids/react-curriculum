import React, { Component } from 'react';

class Footer extends Component {
  render() {
    return (
      <footer>Copyright</footer>
    );
  }
}

export default Footer;
