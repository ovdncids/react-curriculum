import React, { Component } from 'react';

class Header extends Component {
  render() {
    return (
      <header><h1>React Study</h1></header>
    );
  }
}

export default Header;
