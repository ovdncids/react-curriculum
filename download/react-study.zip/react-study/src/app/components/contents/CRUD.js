import React, { Component } from 'react';
import { inject, observer } from 'mobx-react';
import _ from 'lodash';
import moment from 'moment';

class CRUD extends Component {
  create(target) {
    const { crudStore } = this.props;
    crudStore.create(target);
  }

  update(target, key) {
    const { crudStore } = this.props;
    crudStore.update(target, key);
  }

  delete(target, key) {
    const { crudStore } = this.props;
    crudStore.delete(target, key);
  }

  render() {
    const { crudStore } = this.props;
    const { member, members } = crudStore;
    return (
      <div>
        <h3>CRUD</h3>
        <hr className="d-block" />
        <div>
          <h4>Read</h4>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Age</th>
                <th>Created Date</th>
                <th>Modify</th>
              </tr>
            </thead>
            <tbody>
            {_.map(members, (member, key) => (
              <tr key={key}>
                <td>
                  <input
                    type="text" placeholder="Name" value={member.name}
                    onChange={e => {member.name = e.target.value}}
                  />
                </td>
                <td>
                  <input
                    type="text" placeholder="Age" value={member.age}
                    onChange={e => {member.age = e.target.value}}
                  />
                </td>
                <td>{moment(member.createdDate).format('YYYY-MM-DD')}</td>
                <td>
                  <button className="relative pointer" onClick={e => this.update(e.target, key)}>Update</button>
                  <button className="relative pointer" onClick={e => this.delete(e.target, key)}>Delete</button>
                </td>
              </tr>
            ))}
            </tbody>
          </table>
        </div>
        <hr className="d-block" />
        <div>
          <h4>Create</h4>
          <input
            type="text" placeholder="Name" value={member.name}
            onChange={e => {member.name = e.target.value}}
          />
          <input
            type="text" placeholder="Age" value={member.age}
            onChange={e => {member.age = e.target.value}}
          />
          <button className="relative pointer" onClick={e => this.create(e.target)}>Create</button>
        </div>
      </div>
    );
  }

  // Life cycle
  componentDidMount() {
    const { crudStore } = this.props;
    crudStore.setMemberInit();
    crudStore.read();
  }
}

CRUD = inject('crudStore')(observer(CRUD))

export default CRUD;
