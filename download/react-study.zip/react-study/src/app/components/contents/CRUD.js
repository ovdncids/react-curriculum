import React, { Component } from 'react';
import { inject, observer } from 'mobx-react';

class CRUD extends Component {
  create(target) {
    const { crudStore } = this.props;
    crudStore.create(target);
  }

  render() {
    const { crudStore } = this.props;
    const { member } = crudStore;
    return (
      <div>
        <h3>CRUD</h3>
        <hr className="d-block" />
        <div>
          <h4>Read</h4>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Age</th>
                <th>Created Date</th>
                <th>Modify</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>횽길동</td>
                <td>39</td>
                <td>2018-10-04</td>
                <td>
                  <button>Update</button>
                  <button>Delete</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <hr className="d-block" />
        <div>
          <h4>Create</h4>
          <input
            type="text" placeholder="Name" value={member.name}
            onChange={e => {member.name = e.target.value}}
          />
          <input
            type="text" placeholder="Age" value={member.age}
            onChange={e => {member.age = e.target.value}}
          />
          <button className="relative" onClick={e => this.create(e.target)}>Create</button>
        </div>
      </div>
    );
  }

  componentDidMount() {
    const { crudStore } = this.props;
    crudStore.setMemberInit();
  }
}

CRUD = inject('crudStore')(observer(CRUD))

export default CRUD;
