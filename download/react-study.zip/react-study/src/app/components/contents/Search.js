import React, { Component } from 'react';

class Search extends Component {
  render() {
    return (
      <div>
        <h3>Search</h3>
        <p>Contents</p>
      </div>
    );
  }
}

export default Search;
