import { decorate, observable } from 'mobx';
import axios from 'axios';
import { toastr, spinner } from '../utils';

class CRUDStore {
  member = {
    name: '',
    age: ''
  }

  setMemberInit() {
    this.member = {
      name: '',
      age: ''
    }
  }

  create(spinnerTarget) {
    // validation
    if (!this.member.name) {
      toastr().warning('Please text your name.');
      return;
    }
    if (!Number(this.member.age) || Number(this.member.age) <= 0) {
      toastr().warning('Please text your age and upper than 0.');
      return;
    }
    const Spinner = spinner().spin(spinnerTarget);
    axios.post('http://localhost:3100/api/v1/member', this.member).then(response => {
      console.log(response);
      Spinner.stop();
    }).catch(error => {
      // apiCommonError(error, spinner);
    });
  }
}

decorate(CRUDStore, {
  member: observable
})

export const crudStore = new CRUDStore();
