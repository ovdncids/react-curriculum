import Toastr from 'toastr';
import 'toastr/build/toastr.min.css';
import { Spinner } from 'spin.js';
import 'spin.js/spin.css';

export const toastr = () => {
  return Toastr;
};

Toastr.options.closeButton = true;
Toastr.options.hideDuration = 200;

export const spinner = () => {
  return new Spinner({scale: 0.5});
};
