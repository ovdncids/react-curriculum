function Footer() {
  return (
    <footer>Copyright</footer>
  )
}

export default Footer;
