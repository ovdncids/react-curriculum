function Header() {
  return (
    <header>
      <h1>React study</h1>
    </header>
  )
}

export default Header;
