import { useEffect } from 'react';
import MembersStore from '../../stores/MembersStore.js';

function Members() {
  const membersStore = MembersStore((state) => state);
  const member = membersStore.member;
  const members = membersStore.members;
  console.log(member, members);
  const memberSet = membersStore.memberSet;
  const membersRead = membersStore.membersRead;
  useEffect(() => {
    memberSet({
      name: '',
      age: ''
    });
    membersRead();
  }, [memberSet, membersRead]);
  return (
    <div>
      <h3>Members</h3>
      <hr className="d-block" />
      <div>
        <h4>Read</h4>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
              <th>Modify</th>
            </tr>
          </thead>
          <tbody>
          {members.map((member, index) => (
            <tr key={index}>
              <td>
                <input
                  type="text" placeholder="Name" value={member.name}
                  onChange={event => {
                    member.name = event.target.value;
                    membersStore.membersSet(members);
                  }}
                />
              </td>
              <td>
                <input
                  type="text" placeholder="Age" value={member.age}
                  onChange={event => {
                    member.age = event.target.value;
                    membersStore.membersSet(members);
                  }}
                />
              </td>
              <td>
                <button onClick={() => {
                  membersStore.membersUpdate(index, member);
                }}>Update</button>
                <button onClick={() => {
                  membersStore.membersDelete(index);
                }}>Delete</button>
              </td>
            </tr>
          ))}
          </tbody>
        </table>
      </div>
      <hr className="d-block" />
      <div>
        <h4>Create</h4>
        <input
          type="text" placeholder="Name" value={member.name}
          onChange={event => {
            member.name = event.target.value;
            membersStore.memberSet(member);
          }}
        />
        <input
          type="text" placeholder="Age" value={member.age}
          onChange={event => {
            member.age = event.target.value;
            membersStore.memberSet(member);
          }}
        />
        <button onClick={() => {
          membersStore.membersCreate(member);
        }}>Create</button>
      </div>
    </div>
  );
}

export default Members;
