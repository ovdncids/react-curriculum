import { useEffect } from 'react';
import { useRecoilState, useRecoilValue, useRecoilCallback } from 'recoil';
import { memberState, membersState, membersRead, membersCreate, membersDelete, membersUpdate } from '../../stores/members';

function Members() {
  const [member, setMember] = useRecoilState(memberState);
  const [[...members], setMembers] = useRecoilState(membersState);
  const _membersRead = useRecoilValue(membersRead);
  const _membersCreate = useRecoilCallback(membersCreate);
  const _membersDelete = useRecoilCallback(membersDelete);
  const _membersUpdate = useRecoilCallback(membersUpdate);
  useEffect(() => {
    setMembers(_membersRead);
  }, [setMembers, _membersRead]);
  return (
    <div>
      <h3>Members</h3>
      <hr className="d-block" />
      <div>
        <h4>Read</h4>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
              <th>Modify</th>
            </tr>
          </thead>
          <tbody>
          {members.map(({...member}, index) => (
            <tr key={index}>
              <td>
                <input
                  type="text" placeholder="Name" value={member.name}
                  onChange={event => {
                    member.name = event.target.value;
                    members[index] = member;
                    setMembers(members);
                  }}
                />
              </td>
              <td>
                <input
                  type="text" placeholder="Age" value={member.age}
                  onChange={event => {
                    member.age = event.target.value;
                    members[index] = member;
                    setMembers(members);
                  }}
                />
              </td>
              <td>
                <button onClick={() => {
                  _membersUpdate(index, member);
                }}>Update</button>
                <button onClick={() => {
                  _membersDelete(index);
                }}>Delete</button>
              </td>
            </tr>
          ))}
          </tbody>
        </table>
      </div>
      <hr className="d-block" />
      <div>
        <h4>Create</h4>
        <input
          type="text" placeholder="Name" value={member.name}
          onChange={event => {
            setMember({
              ...member,
              name: event.target.value
            });
          }}
        />
        <input
          type="text" placeholder="Age" value={member.age}
          onChange={event => {
            setMember({
              ...member,
              age: event.target.value
            });
          }}
        />
        <button onClick={() => {
          _membersCreate(member);
        }}>Create</button>
      </div>
    </div>
  )
}

export default Members;
