import { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { stateMembers } from 'store/members/membersSlice.js';
import actionsMembers from 'store/members/membersActions.js';

function Members() {
  const dispatch = useDispatch();
  const member = {...useSelector(stateMembers).member};
  const members = JSON.parse(JSON.stringify(useSelector(stateMembers).members));
  useEffect(() => {
    dispatch(actionsMembers.memberSet({
      name: '',
      age: ''
    }));
    dispatch(actionsMembers.membersRead());
  }, [dispatch]);
  return (
    <div>
      <h3>Members</h3>
      <hr className="d-block" />
      <div>
        <h4>Read</h4>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
              <th>Modify</th>
            </tr>
          </thead>
          <tbody>
          {members.map((member, index) => (
            <tr key={index}>
              <td>
                <input
                  type="text" placeholder="Name" value={member.name}
                  onChange={event => {member.name = event.target.value; dispatch(actionsMembers.membersSet(members))}}
                />
              </td>
              <td>
                <input
                  type="text" placeholder="Age" value={member.age}
                  onChange={event => {member.age = event.target.value; dispatch(actionsMembers.membersSet(members))}}
                />
              </td>
              <td>
                <button onClick={() => dispatch(actionsMembers.membersUpdate({index, member}))}>Update</button>
                <button onClick={() => dispatch(actionsMembers.membersDelete(index))}>Delete</button>
              </td>
            </tr>
          ))}
          </tbody>
        </table>
      </div>
      <hr className="d-block" />
      <div>
        <h4>Create</h4>
        <input
          type="text" placeholder="Name" value={member.name}
          onChange={event => {member.name = event.target.value; dispatch(actionsMembers.memberSet(member))}}
        />
        <input
          type="text" placeholder="Age" value={member.age}
          onChange={event => {member.age = event.target.value; dispatch(actionsMembers.memberSet(member))}}
        />
        <button onClick={() => dispatch(actionsMembers.membersCreate(member))}>Create</button>
      </div>
    </div>
  )
}

export default Members;
