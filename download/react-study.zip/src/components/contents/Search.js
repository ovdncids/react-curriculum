import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { stateMembers } from 'store/members/membersSlice.js';
import actionsSearch from 'store/search/searchActions.js';

function Search(props) {
  const url = new URL(window.location.href);
  const spSearch = url.searchParams.get('search') || '';
  const { history } = props;
  const dispatch = useDispatch();
  const members = useSelector(stateMembers).members;
  const [ search, setSearch ] = useState('');
  const searchRead = (search) => {
    history.push(`/search?search=${search}`);
  };
  useEffect(() => {
  setSearch(spSearch);
  dispatch(actionsSearch.searchRead(spSearch));
}, [dispatch, spSearch]);
  return (
    <div>
      <h3>Search</h3>
      <hr className="d-block" />
      <div>
        <input type="text"
          value={search}
          onChange={event => {setSearch(event.target.value)}}
          onKeyUp={event => {if (event.key === 'Enter') searchRead(search)}}
        />
        <button onClick={() => searchRead(search)}>Search</button>
      </div>
      <hr className="d-block" />
      <div>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
            </tr>
          </thead>
          <tbody>
          {members.map((member, index) => (
            <tr key={index}>
              <td>{member.name}</td>
              <td>{member.age}</td>
            </tr>
          ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default Search;
