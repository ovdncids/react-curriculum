import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { stateMembers } from 'store/members/membersSlice.js';
import actionsSearch from 'store/search/searchActions.js';

function Search(props) {
  const url = new URL(window.location.href);
  const spSearch = url.searchParams.get('q') || '';
  const { history } = props;
  const dispatch = useDispatch();
  const members = useSelector(stateMembers).members;
  const [ q, setQ ] = useState('');
  const searchRead = (event) => {
    history.push(`/search?q=${q}`);
    event.preventDefault();
  };
  useEffect(() => {
    setQ(spSearch);
    dispatch(actionsSearch.searchRead(spSearch));
  }, [dispatch, spSearch]);
  return (
    <div>
      <h3>Search</h3>
      <hr className="d-block" />
      <div>
        <form onSubmit={(event) => {searchRead(event)}}>
          <input type="text"
            value={q}
            onChange={event => {setQ(event.target.value)}}
          />
          <button>Search</button>
        </form>
      </div>
      <hr className="d-block" />
      <div>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
            </tr>
          </thead>
          <tbody>
          {members.map((member, index) => (
            <tr key={index}>
              <td>{member.name}</td>
              <td>{member.age}</td>
            </tr>
          ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default Search;
