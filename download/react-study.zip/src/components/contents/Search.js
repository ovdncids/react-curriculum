import { useState, useEffect } from 'react';
import { inject, observer } from 'mobx-react';

function Search(props) {
  const url = new URL(window.location.href);
  const spSearch = url.searchParams.get('search') || '';
  const { membersStore, searchStore, history } = props;
  const { members } = membersStore;
  const [ search, setSearch ] = useState('');
  const searchRead = (search) => {
    history.push(`/search?search=${search}`);
  };
  useEffect(() => {
    searchStore.searchRead(spSearch);
    setSearch(spSearch);
  }, [searchStore, spSearch]);
  return (
    <div>
      <h3>Search</h3>
      <hr className="d-block" />
      <div>
        <input type="text"
          value={search}
          onChange={event => {setSearch(event.target.value)}}
          onKeyPress={event => {if (event.key === 'Enter') searchRead(search)}}
        />
        <button onClick={() => searchRead(search)}>Search</button>
      </div>
      <hr className="d-block" />
      <div>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
            </tr>
          </thead>
          <tbody>
          {members.map((member, index) => (
            <tr key={index}>
              <td>{member.name}</td>
              <td>{member.age}</td>
            </tr>
          ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default inject('membersStore', 'searchStore')(observer(Search));
