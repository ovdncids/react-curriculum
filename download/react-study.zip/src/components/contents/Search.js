import { useState, useEffect } from 'react';
import { usersStore } from '../../stores/usersStore.js';
import { searchActions } from '../../stores/searchStore.js';
import { useLocation, useNavigate } from 'react-router-dom';

function Search() {
  const location = useLocation();
  const navigate = useNavigate();
  const searchParams = new URLSearchParams(location.search);
  const _q = searchParams.get('q') || '';
  const users = usersStore((state) => state).users;
  const [ q, setQ ] = useState(_q);
  const searchRead = (event) => {
    event.preventDefault();
    navigate('/search?q=' + q);
  };
  useEffect(() => {
    searchActions.searchRead(_q);
    setQ(_q);
  }, [_q]);
  return (
    <div>
      <h3>Search</h3>
      <hr className="d-block" />
      <div>
        <form onSubmit={(event) => {searchRead(event)}}>
          <input
            type="text" placeholder="Search"
            value={q}
            onChange={event => {setQ(event.target.value)}}
          />
          <button>Search</button>
        </form>
      </div>
      <hr className="d-block" />
      <div>
        <table className="table-search">
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
            </tr>
          </thead>
          <tbody>
          {users.map((user, index) => (
            <tr key={index}>
              <td>{user.name}</td>
              <td>{user.age}</td>
            </tr>
          ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Search;
