import { useEffect } from 'react';
import { usersStore, usersAction } from '../../stores/usersStore.js';

function Users() {
  const usersState = usersStore((state) => state);
  const user = usersState.user;
  const users = usersState.users;
  console.log(user, users);
  useEffect(() => {
    usersAction.userSet({
      name: '',
      age: ''
    });
    usersAction.usersRead();
  }, []);
  return (
    <div>
      <h3>Users</h3>
      <hr className="d-block" />
      <div>
        <h4>Read</h4>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
              <th>Modify</th>
            </tr>
          </thead>
          <tbody>
          {users.map((user, index) => (
            <tr key={index}>
              <td>
                <input
                  type="text" placeholder="Name" value={user.name}
                  onChange={event => {
                    user.name = event.target.value;
                    usersAction.usersSet(users);
                  }}
                />
              </td>
              <td>
                <input
                  type="text" placeholder="Age" value={user.age}
                  onChange={event => {
                    user.age = event.target.value;
                    usersAction.usersSet(users);
                  }}
                />
              </td>
              <td>
                <button onClick={() => {
                  usersAction.usersUpdate(index, user);
                }}>Update</button>
                <button onClick={() => {
                  usersAction.usersDelete(index);
                }}>Delete</button>
              </td>
            </tr>
          ))}
          </tbody>
        </table>
      </div>
      <hr className="d-block" />
      <div>
        <h4>Create</h4>
        <input
          type="text" placeholder="Name" value={user.name}
          onChange={event => {
            user.name = event.target.value;
            usersAction.userSet(user);
          }}
        />
        <input
          type="text" placeholder="Age" value={user.age}
          onChange={event => {
            user.age = event.target.value;
            usersAction.userSet(user);
          }}
        />
        <button onClick={() => {
          usersAction.usersCreate(user);
        }}>Create</button>
      </div>
    </div>
  );
}

export default Users;
