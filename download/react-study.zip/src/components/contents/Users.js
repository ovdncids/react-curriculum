import { useEffect } from 'react';
import UsersStore from '../../stores/UsersStore.js';

function Users() {
  const usersStore = UsersStore((state) => state);
  const user = usersStore.user;
  const users = usersStore.users;
  console.log(user, users);
  const userSet = usersStore.userSet;
  const usersRead = usersStore.usersRead;
  useEffect(() => {
    userSet({
      name: '',
      age: ''
    });
    usersRead();
  }, [userSet, usersRead]);
  return (
    <div>
      <h3>Users</h3>
      <hr className="d-block" />
      <div>
        <h4>Read</h4>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
              <th>Modify</th>
            </tr>
          </thead>
          <tbody>
          {users.map((user, index) => (
            <tr key={index}>
              <td>
                <input
                  type="text" placeholder="Name" value={user.name}
                  onChange={event => {
                    user.name = event.target.value;
                    usersStore.usersSet(users);
                  }}
                />
              </td>
              <td>
                <input
                  type="text" placeholder="Age" value={user.age}
                  onChange={event => {
                    user.age = event.target.value;
                    usersStore.usersSet(users);
                  }}
                />
              </td>
              <td>
                <button onClick={() => {
                  usersStore.usersUpdate(index, user);
                }}>Update</button>
                <button onClick={() => {
                  usersStore.usersDelete(index);
                }}>Delete</button>
              </td>
            </tr>
          ))}
          </tbody>
        </table>
      </div>
      <hr className="d-block" />
      <div>
        <h4>Create</h4>
        <input
          type="text" placeholder="Name" value={user.name}
          onChange={event => {
            user.name = event.target.value;
            usersStore.userSet(user);
          }}
        />
        <input
          type="text" placeholder="Age" value={user.age}
          onChange={event => {
            user.age = event.target.value;
            usersStore.userSet(user);
          }}
        />
        <button onClick={() => {
          usersStore.usersCreate(user);
        }}>Create</button>
      </div>
    </div>
  );
}

export default Users;
