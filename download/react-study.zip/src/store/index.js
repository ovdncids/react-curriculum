import { configureStore } from '@reduxjs/toolkit';
import ReduxThunk from 'redux-thunk';
import membersReducer from './members/membersSlice.js';

export default configureStore({
  reducer: {
    members: membersReducer
  },
  middleware: [
    ReduxThunk
  ]
});
