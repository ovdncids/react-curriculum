import { configureStore } from '@reduxjs/toolkit';
import createSagaMiddleware from 'redux-saga';
import { all } from 'redux-saga/effects'
import membersReducer from './members/membersSlice.js';
import { takeEveryMembers } from './members/membersActions.js';
import { takeEverySearch } from './search/searchActions.js';

const sagaMiddleware = createSagaMiddleware();

export default configureStore({
  reducer: {
    members: membersReducer
  },
  middleware : [ sagaMiddleware ]
});

sagaMiddleware.run(function* () {
  yield all([takeEveryMembers(), takeEverySearch()]);
});
