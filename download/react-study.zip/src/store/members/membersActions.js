import axios from 'axios';
import { axiosError } from '../common.js';
import { actionsMembers } from './membersSlice.js';

const actions = {
  memberSet: payload => (dispatch) => {
    dispatch(actionsMembers.memberSet(payload));
  },
  membersSet: payload => (dispatch) => {
    dispatch(actionsMembers.membersSet(payload));
  },
  membersCreate: payload => (dispatch) => {
    axios.post('/api/v1/members', payload).then((response) => {
      console.log('Done membersCreate', response);
      (actions.membersRead())(dispatch);
    }).catch((error) => {
      axiosError(error);
    });
  },
  membersRead: () => (dispatch) => {
    axios.get('/api/v1/members').then((response) => {
      console.log('Done membersRead', response);
      dispatch(actionsMembers.membersRead(response.data.members));
    }).catch((error) => {
      axiosError(error);
    });
  },
  membersUpdate: payload => (dispatch) => {
    axios.patch('/api/v1/members', payload).then((response) => {
      console.log('Done membersUpdate', response);
      (actions.membersRead())(dispatch);
    }).catch((error) => {
      axiosError(error);
    });
  },
  membersDelete: payload => (dispatch) => {
    axios.delete('/api/v1/members/' + payload).then((response) => {
      console.log('Done membersDelete', response);
      (actions.membersRead())(dispatch);
    }).catch((error) => {
      axiosError(error);
    });
  }
};

export default actions;
