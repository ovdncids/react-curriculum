import axios from 'axios';
import { axiosError } from '../common.js';
import { put, takeEvery, call } from 'redux-saga/effects';
import { createAction } from '@reduxjs/toolkit';
import { actionsMembers } from './membersSlice.js';

export const memberSet = createAction('memberSet', payload => {return {payload: payload}});
export const membersSet = createAction('membersSet', payload => {return {payload: payload}});
export const membersCreate = createAction('membersCreate', payload => {return {payload: payload}});
export const membersRead = createAction('membersRead', payload => {return {payload: payload}});
export const membersUpdate = createAction('membersUpdate', payload => {return {payload: payload}});
export const membersDelete = createAction('membersDelete', payload => {return {payload: payload}});

export function* takeEveryMembers() {
  yield takeEvery(memberSet, function* (action) {
    yield put(actionsMembers.memberSet(action.payload));
  });

  yield takeEvery(membersSet, function* (action) {
    yield put(actionsMembers.membersSet(action.payload));
  });

  yield takeEvery(membersCreate, function* (action) {
    try {
      const response = yield call(() => axios.post('/api/v1/members', action.payload));
      console.log('Done membersCreate', response);
      yield membersRead$();
    } catch(error) {
      axiosError(error);
    }
  });

  const membersRead$ = function* () {
    try {
      const response = yield call(() => axios.get('/api/v1/members'));
      console.log('Done membersRead', response);
      yield put(actionsMembers.membersRead(response.data.members));
    } catch(error) {
      axiosError(error);
    }
  };
  yield takeEvery(membersRead, membersRead$);

  yield takeEvery(membersUpdate, function* (action) {
    try {
      const response = yield call(() => axios.patch('/api/v1/members', action.payload));
      console.log('Done membersUpdate', response);
      yield membersRead$();
    } catch(error) {
      axiosError(error);
    }
  });

  yield takeEvery(membersDelete, function* (action) {
    try {
      const response = yield call(() => axios.delete('/api/v1/members/' + action.payload));
      console.log('Done membersUpdate', response);
      yield membersRead$();
    } catch(error) {
      axiosError(error);
    }
  });
}

const actions = {
  memberSet,
  membersSet,
  membersCreate,
  membersRead,
  membersUpdate,
  membersDelete
}

export default actions;
