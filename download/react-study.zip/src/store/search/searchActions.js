import axios from 'axios';
import { axiosError } from '../common.js';
import { actionsMembers } from 'store/members/membersSlice.js';

const actions = {
  searchRead: search => (dispatch) => {
    const url = `/api/v1/search?search=${search}`;
    axios.get(url).then((response) => {
      console.log('Done searchRead', response);
      dispatch(actionsMembers.membersRead(response.data.members));
    }).catch((error) => {
      axiosError(error);
    });
  }
};

export default actions;
