import { create } from 'zustand';
import axios from 'axios';
import { axiosError } from './common.js';

const MembersStore = create((set, get) => ({
  members: [],
  member: {
    name: '',
    age: ''
  },
  memberSet: (member) => {
    set(() => ({ member }));
  },
  membersSet: (members) => {
    set(() => ({ members }));
  },
  membersCreate: async (member) => {
    try {
      const response = await axios.post('http://localhost:3100/api/v1/members', member);
      console.log('Done membersCreate', response);
      get().membersRead();
    } catch(error) {
      axiosError(error);
    }
  },
  membersRead: async () => {
    try {
      const response = await axios.get('http://localhost:3100/api/v1/members');
      console.log('Done membersRead', response);
      set({ members: response.data.members });
    } catch(error) {
      axiosError(error);
    }
  },
  membersDelete: async (index) => {
    try {
      const response = await axios.delete('http://localhost:3100/api/v1/members/' + index);
      console.log('Done membersDelete', response);
      get().membersRead();
    } catch(error) {
      axiosError(error);
    }
  },
  membersUpdate: async (index, member) => {
    try {
      const response = await axios.patch('http://localhost:3100/api/v1/members/' + index, member);
      console.log('Done membersUpdate', response);
      get().membersRead();
    } catch(error) {
      axiosError(error);
    }
  }
}));

export default MembersStore;
