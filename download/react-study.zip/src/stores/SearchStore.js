import { create } from 'zustand';
import UsersStore from './UsersStore.js';
import axios from 'axios';
import { axiosError } from './common.js';

const SearchStore = create(() => ({
  searchRead: async (q) => {
    try {
      const response = await axios.get('http://localhost:3100/api/v1/search?q=' + q);
      console.log('Done searchRead', response);
      UsersStore.setState({ users: response.data.users });
    } catch(error) {
      axiosError(error);
    }
  }
}));

export default SearchStore;
