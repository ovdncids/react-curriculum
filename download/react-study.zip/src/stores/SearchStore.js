import { create } from 'zustand';
import MembersStore from './MembersStore.js';
import axios from 'axios';
import { axiosError } from './common.js';

const SearchStore = create(() => ({
  searchRead: async (q) => {
    try {
      const response = await axios.get('http://localhost:3100/api/v1/search?q=' + q);
      console.log('Done searchRead', response);
      MembersStore.setState({ members: response.data.members });
    } catch(error) {
      axiosError(error);
    }
  }
}));

export default SearchStore;
