import { create } from 'zustand';
import axios from 'axios';
import { axiosError } from './common.js';

const UsersStore = create((set, get) => ({
  users: [],
  user: {
    name: '',
    age: ''
  },
  userSet: (user) => {
    set({ user });
  },
  usersSet: (users) => {
    set({ users });
  },
  usersCreate: async (user) => {
    try {
      const response = await axios.post('http://localhost:3100/api/v1/users', user);
      console.log('Done usersCreate', response);
      get().usersRead();
    } catch(error) {
      axiosError(error);
    }
  },
  usersRead: async () => {
    try {
      const response = await axios.get('http://localhost:3100/api/v1/users');
      console.log('Done usersRead', response);
      set({ users: response.data.users });
    } catch(error) {
      axiosError(error);
    }
  },
  usersDelete: async (index) => {
    try {
      const response = await axios.delete('http://localhost:3100/api/v1/users/' + index);
      console.log('Done usersDelete', response);
      get().usersRead();
    } catch(error) {
      axiosError(error);
    }
  },
  usersUpdate: async (index, user) => {
    try {
      const response = await axios.patch('http://localhost:3100/api/v1/users/' + index, user);
      console.log('Done usersUpdate', response);
      get().usersRead();
    } catch(error) {
      axiosError(error);
    }
  }
}));

export default UsersStore;
