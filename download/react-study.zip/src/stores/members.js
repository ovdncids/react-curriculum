import { atom, selector } from 'recoil';
import axios from 'axios';
import { axiosError } from './common.js';

export const memberState = atom({
  key: 'memberState',
  default: {
    name: '',
    age: ''
  }
});

export const membersState = atom({
  key: 'membersState',
  default: []
});

export const membersService = {
  create: async (member) => {
    try {
      const response = await axios.post('http://localhost:3100/api/v1/members', member);
      console.log('Done membersRead', response);
      return response.data;
    } catch(error) {
      axiosError(error);
    }
  },
  read: async () => {
    try {
      const response = await axios.get('http://localhost:3100/api/v1/members');
      console.log('Done membersCreate', response);
      return response.data.members;
    } catch(error) {
      axiosError(error);
    }
  },
  delete: async (index) => {
    try {
      const response = await axios.delete('http://localhost:3100/api/v1/members/' + index);
      console.log('Done membersDelete', response);
      return response.data;
    } catch(error) {
      axiosError(error);
    }
  },
  update: async (index, member) => {
    try {
      const response = await axios.patch('http://localhost:3100/api/v1/members/' + index, member);
      console.log('Done membersUpdate', response);
      return response.data;
    } catch(error) {
      axiosError(error);
    }
  }
};

export const membersRead = selector({
  key: 'membersRead',
  get: membersService.read
});

export const membersCreate = ({set}) => async (member) => {
  await membersService.create(member);
  const members = await membersService.read();
  set(membersState, members)
};

export const membersDelete = ({set}) => async (index) => {
  await membersService.delete(index);
  const members = await membersService.read();
  set(membersState, members)
};

export const membersUpdate = ({set}) => async (index, member) => {
  await membersService.update(index, member);
  const members = await membersService.read();
  set(membersState, members)
};
