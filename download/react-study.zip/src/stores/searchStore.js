import { usersActions } from './usersStore.js';
import axios from 'axios';
import { axiosError } from './common.js';

export const searchActions = {
  searchRead: async (q) => {
    try {
      const response = await axios.get('http://localhost:3100/api/v1/search?q=' + q);
      console.log('Done searchRead', response);
      usersActions.usersSet(response.data.users);
    } catch(error) {
      axiosError(error);
    }
  }
};
