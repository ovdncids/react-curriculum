import { usersAction } from './usersStore.js';
import axios from 'axios';
import { axiosError } from './common.js';

export const searchAction = {
  searchRead: async (q) => {
    try {
      const response = await axios.get('http://localhost:3100/api/v1/search?q=' + q);
      console.log('Done searchRead', response);
      usersAction.usersSet(response.data.users);
    } catch(error) {
      axiosError(error);
    }
  }
};
