import { create } from 'zustand';
import axios from 'axios';
import { axiosError } from './common.js';

export const usersStore = create(() => ({
  users: [],
  user: {
    name: '',
    age: ''
  }
}));

export const usersActions = {
  userSet: (user) => {
    usersStore.setState({ user });
  },
  usersSet: (users) => {
    usersStore.setState({ users });
  },
  usersCreate: async (user) => {
    try {
      const response = await axios.post('http://localhost:3100/api/v1/users', user);
      console.log('Done usersCreate', response);
      usersActions.usersRead();
    } catch(error) {
      axiosError(error);
    }
  },
  usersRead: async () => {
    try {
      const response = await axios.get('http://localhost:3100/api/v1/users');
      console.log('Done usersRead', response);
      usersActions.usersSet(response.data.users);
    } catch(error) {
      axiosError(error);
    }
  },
  usersDelete: async (index) => {
    try {
      const response = await axios.delete('http://localhost:3100/api/v1/users/' + index);
      console.log('Done usersDelete', response);
      usersActions.usersRead();
    } catch(error) {
      axiosError(error);
    }
  },
  usersUpdate: async (index, user) => {
    try {
      const response = await axios.patch('http://localhost:3100/api/v1/users/' + index, user);
      console.log('Done usersUpdate', response);
      usersActions.usersRead();
    } catch(error) {
      axiosError(error);
    }
  }
};
