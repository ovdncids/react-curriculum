const express = require('express');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const mongoose = require('mongoose');
const restify = require('express-restify-mongoose');
const app = express();
const router = express.Router();

// Start: Request, Response Settings
app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With, Accept, Content-Type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  next();
});
// End: Request, Response Settings

// Start: app setting
app.use(bodyParser.json());
app.use(methodOverride());
app.use(router);
// End: app setting

// Start: subscribe
var subscribe = false;

app.get('/subscribe', function(req, res) {
  console.log('subscribe = ' + subscribe);
  res.status(200).send(subscribe);
});

app.post('/subscribe', function(req, res) {
  subscribe = req.body.subscribe;
  console.log(req.body);
  console.log('subscribe = ' + subscribe);
  res.status(200).send(subscribe);
});
// End: subscribe

// Start: mongoose
mongoose.connect('mongodb://localhost:27017/local');

restify.serve(router, mongoose.model('subscribe', new mongoose.Schema({
  subscribe: { type: Boolean, required: true }
})));

restify.serve(router, mongoose.model('men', new mongoose.Schema({
  subscribe: { type: Boolean, required: true }
})));

restify.serve(router, mongoose.model('member', new mongoose.Schema({
  name: { type: String, required: true },
  age: { type: Number, required: true }
})));
// End: mongoose

// Start: start server
app.listen(3001, function() {
  console.log('Express server listening on port 3001')
});
// End: start server
