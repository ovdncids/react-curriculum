import * as React from 'react';
import { HashRouter, Route, Link } from 'react-router-dom';
import Main from './routes/main';
import Subscribe from './routes/subscribe';

class App extends React.Component<{}, {}> {
  render() {
    return (
      <HashRouter>
        <div>
          <div>
            <h1>Header</h1>
            <ul>
              <li><Link to="/">main</Link></li>
              <li><Link to="/subscribe">subscribe</Link></li>
            </ul>
          </div>
          <hr />

          <Route exact={true} path="/" component={Main}/>
          <Route path="/subscribe" component={Subscribe}/>
        </div>
      </HashRouter>
    );
  }
}

export default App;
