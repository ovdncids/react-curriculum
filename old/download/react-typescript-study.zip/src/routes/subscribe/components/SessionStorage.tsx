import * as React from 'react';

class Body extends React.Component<{}, {}> {
  render() {
    return (
      <div>Body</div>
    );
  }
}

const SessionStorage = () => (
  <div>
    <h3>SessionStorage</h3>
    <Body />
  </div>
);

export default SessionStorage;
