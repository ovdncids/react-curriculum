import * as React from 'react';

class Body extends React.Component<{}, {}> {
  render() {
    return (
      <div>Body</div>
    );
  }
}

const State = () => (
  <div>
    <h3>State</h3>
    <Body />
  </div>
);

export default State;
