import * as React from 'react';
import { Route, Link } from 'react-router-dom';
import State from './components/State';
import SessionStorage from './components/SessionStorage';

const Subscribe = ({ match }: any) => (
  <div>
    <h2>Subscribe</h2>
    <ul>
      <li><Link to={`${match.url}/state`}>state</Link></li>
      <li><Link to={`${match.url}/session`}>sessionStorage</Link></li>
    </ul>
    <hr />

    <Route path={`${match.url}/state`} component={State}/>
    <Route path={`${match.url}/session`} component={SessionStorage}/>
  </div>
);

export default Subscribe;
