import React from 'react'

class Footer extends React.Component {
  render () {
    return (
      <div style={{ color: 'white', backgroundColor: 'blue' }}>
        Footer
      </div>
    )
  }
}

export default Footer
