import React from 'react'
import { IndexLink, Link } from 'react-router'
import PropTypes from 'prop-types'
import Footer from '../../components/Footer'
import i18next, { t } from 'i18next'
import './PageLayout.scss'

export const PageLayout = ({ children }) => (
  <div className='container text-center'>
    <h1>React Redux Starter Kit</h1>
    <IndexLink to='/' activeClassName='page-layout__nav-item--active'>{t('Home')}</IndexLink>
    {' · '}
    <Link to='/counter' activeClassName='page-layout__nav-item--active'>{t('Counter')}</Link>
    {' · '}
    <Link to='/hello' activeClassName='page-layout__nav-item--active'>{t('Hello')}</Link>
    {' · '}
    <Link to='/subscribe' activeClassName='page-layout__nav-item--active'>{t('Subscribe')}</Link>
    {' · '}
    <button onClick={() => i18next.change()}>{t('Change Languages')}</button>
    <div className='page-layout__viewport'>
      {children}
    </div>
    <Footer/>
  </div>
)
PageLayout.propTypes = {
  children: PropTypes.node,
}

export default PageLayout
