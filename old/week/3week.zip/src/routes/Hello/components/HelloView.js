import React from 'react'

export const HelloView = () => (
  <div style={{ backgroundColor: 'pink' }}>
    <h4>Hello</h4>
  </div>
)

export default HelloView
