import HelloView from './components/HelloView'

// Sync route definition
export default {
  component : HelloView
}
