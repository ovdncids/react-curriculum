import React from 'react'

class DBView extends React.Component {
  constructor(props) {
    const subscribe = false;
    super(props);
    this.state = {
      isSubscribe: subscribe
    };
  }

  toggleState() {
    const subscribe = !this.state.isSubscribe;
    console.log('this.state.isSubscribe = ' + this.state.isSubscribe);
    console.log('subscribe = ' + subscribe);
    if (this.state.isSubscribe) {
      console.log('subscribe > server > DELETE > DB');
      fetch('http://localhost:3001/api/v1/subscribe/', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          subscribe: subscribe
        })
      }).then(function(res){
        return res;
      }).then(()=>{
        this.setState({isSubscribe:subscribe});
      });
    } else {
      console.log('subscribe > server > POST > DB');
      fetch('http://localhost:3001/api/v1/subscribe/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          subscribe: subscribe
        })
      }).then(function(res){
        return res.json()
      }).then(()=>{
        this.setState({isSubscribe:subscribe});
      });
    }
  }

  render() {
    return (
      <div style={{ backgroundColor: 'white' }}>
        <h4>SessionStorage</h4>
        {this.state.isSubscribe?
        <div>
          <h2>응모 하셨습니다(감사합니다)</h2>
          <button onClick={this.toggleState.bind(this)}>응모 취소(정말?)</button>
        </div>
        :
        <div>
          <h2>응모 하시겠습니까?</h2>
          <button onClick={this.toggleState.bind(this)}>응모 하기</button>
        </div>
        }
      </div>
    )
  }

  componentDidMount() {
    console.log('subscribe > server > GET > DB');
    fetch('http://localhost:3001/api/v1/subscribe/').then(function(res){
      return res.json();
    }).then((json)=>{
      if (json.length) {
        this.setState({isSubscribe:true});
      }
    });
  }
}

export default DBView
