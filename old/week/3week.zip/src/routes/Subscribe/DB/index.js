import DBView from './components/DBView'

// Sync route definition
export default {
  component : DBView
}
