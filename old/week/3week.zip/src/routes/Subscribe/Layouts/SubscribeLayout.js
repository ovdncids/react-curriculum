import React from 'react'
import { IndexLink } from 'react-router'

export const SubscribeView = ({ children }) => (
  <div style={{ backgroundColor: 'gray' }}>
    <div>
      <h3>Left Menu</h3>
      <IndexLink to='/subscribe/state' activeClassName='page-layout__nav-item--active'>State</IndexLink>
      {' · '}
      <IndexLink to='/subscribe/localStorage' activeClassName='page-layout__nav-item--active'>LocalStorage</IndexLink>
      {' · '}
      <IndexLink to='/subscribe/sessionStorage' activeClassName='page-layout__nav-item--active'>SessionStorage</IndexLink>
      {' · '}
      <IndexLink to='/subscribe/server' activeClassName='page-layout__nav-item--active'>Server</IndexLink>
      {' · '}
      <IndexLink to='/subscribe/db' activeClassName='page-layout__nav-item--active'>DB</IndexLink>
    </div>
    <div>{children}</div>
  </div>
)

export default SubscribeView
