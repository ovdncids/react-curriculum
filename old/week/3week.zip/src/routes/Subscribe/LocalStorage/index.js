import LocalStorageView from './components/LocalStorageView'

// Sync route definition
export default {
  component : LocalStorageView
}
