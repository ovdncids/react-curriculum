import React from 'react'

class ServerView extends React.Component {
  constructor(props) {
    const subscribe = false;
    super(props);
    this.state = {
      isSubscribe: subscribe
    };
  }

  toggleState() {
    console.log('subscribe > server > POST');
    const subscribe = !this.state.isSubscribe;
    fetch('http://localhost:3001/subscribe/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        subscribe: subscribe
      })
    }).then(function(res){
      return res.json()
    }).then((json)=>{
      this.setState({isSubscribe:json});
    });
    //창을 2개 띄우고 테스트
  }

  render() {
    return (
      <div style={{ backgroundColor: 'white' }}>
        <h4>SessionStorage</h4>
        {this.state.isSubscribe?
        <div>
          <h2>응모 하셨습니다(감사합니다)</h2>
          <button onClick={this.toggleState.bind(this)}>응모 취소(정말?)</button>
        </div>
        :
        <div>
          <h2>응모 하시겠습니까?</h2>
          <button onClick={this.toggleState.bind(this)}>응모 하기</button>
        </div>
        }
      </div>
    )
  }

  componentDidMount() {
    console.log('subscribe > server > GET');
    fetch('http://localhost:3001/subscribe/').then(function(res){
      return res.json();
    }).then((json)=>{
      console.log(json);
      this.setState({isSubscribe:json});
    });
  }
}

export default ServerView
