import ServerView from './components/ServerView'

// Sync route definition
export default {
  component : ServerView
}
