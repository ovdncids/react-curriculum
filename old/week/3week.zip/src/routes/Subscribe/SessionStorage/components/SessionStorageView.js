import React from 'react'

class SessionStorageView extends React.Component {
  constructor(props) {
    const subscribe = JSON.parse(sessionStorage.getItem('subscribe'));
    super(props);
    this.state = {
      isSubscribe: subscribe ? true : false
    };
    console.log('현재: isSubscribe = ' + this.state.isSubscribe);
  }

  toggleState() {
    const subscribe = !this.state.isSubscribe;
    sessionStorage.setItem('subscribe', JSON.stringify(subscribe));
    this.setState({isSubscribe:subscribe});
    console.log('변경: isSubscribe = ' + this.state.isSubscribe);
  }

  render () {
    console.log(this.state.isSubscribe);
    return (
      <div style={{ backgroundColor: 'white' }}>
        <h4>SessionStorage</h4>
        {this.state.isSubscribe?
        <div>
          <h2>응모 하셨습니다(감사합니다)</h2>
          <button onClick={this.toggleState.bind(this)}>응모 취소(정말?)</button>
        </div>
        :
        <div>
          <h2>응모 하시겠습니까?</h2>
          <button onClick={this.toggleState.bind(this)}>응모 하기</button>
        </div>
        }
      </div>
    )
  }
}

export default SessionStorageView
