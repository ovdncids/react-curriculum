import SessionStorageView from './components/SessionStorageView'

// Sync route definition
export default {
  component : SessionStorageView
}
