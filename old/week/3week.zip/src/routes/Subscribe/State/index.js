import StateView from './components/StateView'

// Sync route definition
export default {
  component : StateView
}
