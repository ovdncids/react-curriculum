import * as React from 'react';
import { observer } from 'mobx-react';
import { HashRouter, Route, Link, Switch, Redirect } from 'react-router-dom';
import Main from './routes/main';
import Subscribe from './routes/subscribe';
import Member from './routes/member';
import i18n, { I18n } from './shared/stores/i18n';

const Admin = () => {
  const isAdmin = true;
  return(
    isAdmin
      ? <h2>Admin</h2>
      : <Redirect to="/"/>
  );
};

const NotFound = () => (
  <h2>404 Page</h2>
);

@observer
class App extends React.Component<{}, {}> {
  private i18n: I18n;

  constructor() {
    super();
    this.i18n = i18n;
  }

  render() {
    const { t, changeLanguage } = i18n;
    return (
      <HashRouter>
        <div>
          <div>
            <h1>{t('Header')}</h1>
            <ul>
              <li><Link to="/">{t('main')}</Link></li>
              <li><Link to="/admin">{t('admin')}</Link></li>
              <li><Link to="/subscribe">{t('subscribe')}</Link></li>
              <li><Link to="/member">{t('member')}</Link></li>
              <li><button onClick={() => changeLanguage()}>{t('change language')}</button></li>
            </ul>
          </div>
          <hr />
          <Switch>
            <Route exact={true} path="/" component={Main}/>
            <Route path="/admin" component={Admin}/>
            <Route path="/subscribe" component={Subscribe}/>
            <Route path="/member" component={Member}/>
            <Route component={NotFound}/>
          </Switch>
        </div>
      </HashRouter>
    );
  }
}

export default App;
