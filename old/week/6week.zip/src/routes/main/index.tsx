import * as React from 'react';

class Body extends React.Component<{}, {}> {
  render() {
    return (
      <div>Body</div>
    );
  }
}

const Main = () => (
  <div>
    <h2>Main</h2>
    <Body />
  </div>
);

export default Main;
