import * as React from 'react';
import { RouteComponentProps } from 'react-router-dom';

interface Pops {
  route: RouteComponentProps<{}>;
}

export interface Member {
  name: string;
  age: number;
  _id?: string;
}

interface State {
  member: Member;
}

class Body extends React.Component<Pops, State> {
  constructor() {
    super();
    this.state = {
      member: {
        name: '',
        age: 0
      }
    };
  }

  changeName = (e: any) => {
    const { member } = this.state;
    member.name = e.target.value;
    this.setState({member});
  }

  changeAge = (e: any) => {
    const { member } = this.state;
    member.age = Number(e.target.value);
    this.setState({member});
  }

  create = () => {
    const { route } = this.props;
    const { member } = this.state;
    console.log('member > POST');
    fetch('http://localhost:3001/api/v1/member/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(member)
      }).then((res: Response) => {
        return res.json();
      }).then(() => {
        route.history.push('/member/list');
      });
  }

  render () {
    return (
      <div>
        <p>name: <input type="input" onChange={(e) => { this.changeName(e); }}/></p>
        <p>age: <input type="number" onChange={(e) => { this.changeAge(e); }}/></p>
        <button onClick={this.create}>create</button>
      </div>
    );
  }
}

const Create = (props: RouteComponentProps<{}>) => (
  <div>
    <h3>Create</h3>
    <Body route={props}/>
  </div>
);

export default Create;
