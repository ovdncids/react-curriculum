import * as React from 'react';
import { RouteComponentProps } from 'react-router-dom';
import { map } from 'lodash';
import { Member } from './Create';

interface Pops {
  route: RouteComponentProps<{}>;
}

interface State {
  members: Array<Member>;
}

class Body extends React.Component<Pops, State> {
  constructor() {
    super();
    this.state = {
      members: []
    };
  }
  changeName = (e: any, member: Member) => {
    const { members } = this.state;
    member.name = e.target.value;
    this.setState({members});
  }

  changeAge = (e: any, member: Member) => {
    const { members } = this.state;
    member.age = Number(e.target.value);
    this.setState({members});
  }

  update = (member: Member) => {
    console.log('member > PUT');
    fetch('http://localhost:3001/api/v1/member/' + member._id, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(member)
      }).then((res: Response) => {
        return res.json();
      }).then(() => {
        document.location.reload();
      });
  }

  delete = (member: Member) => {
    console.log('member > DELETE');
    fetch('http://localhost:3001/api/v1/member/' + member._id, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      }).then((res: Response) => {
        return res;
      }).then(() => {
        document.location.reload();
      });
  }

  render () {
    const { members } = this.state;
    return (
      <div>
        {map(members, member => (
          <div key={member._id}>
            <span>name: <input type="input" value={member.name} onChange={(e) => { this.changeName(e, member); }}/></span>
            <span>age: <input type="number" value={member.age} onChange={(e) => { this.changeAge(e, member); }}/></span>
            <button onClick={() => { this.update(member); }}>update</button>
            <button onClick={() => { this.delete(member); }}>delete</button>
          </div>
        ))}
      </div>
    );
  }

  componentDidMount() {
    console.log('member > GET');
    fetch('http://localhost:3001/api/v1/member/').then((res: Response) => {
      return res.json();
    }).then((json) => {
      this.setState({members: json});
    });
  }
}

const List = (props: RouteComponentProps<{}>) => (
  <div>
    <h3>List</h3>
    <Body route={props}/>
  </div>
);

export default List;
