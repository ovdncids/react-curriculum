import * as React from 'react';
import { Route, Link, RouteComponentProps } from 'react-router-dom';
import Create from './components/Create';
import List from './components/List';

const Member = (props: RouteComponentProps<{}>) => (
  <div>
    <h2>Member</h2>
    <ul>
      <li><Link to={`${props.match.url}/create`}>create</Link></li>
      <li><Link to={`${props.match.url}/list`}>list</Link></li>
    </ul>
    <hr />

    <Route path={`${props.match.url}/create`} component={Create}/>
    <Route path={`${props.match.url}/list`} component={List}/>
  </div>
);

export default Member;
