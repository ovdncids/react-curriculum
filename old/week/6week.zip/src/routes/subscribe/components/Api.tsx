import * as React from 'react';

interface State {
  isSubscribe: boolean;
}

class Body extends React.Component<{}, State> {
  constructor() {
    super();
    this.state = {
      isSubscribe: false
    };
  }

  toggleState = () => {
    const { isSubscribe } = this.state;
    if (!isSubscribe) {
      console.log('subscribe > POST');
      fetch('http://localhost:3001/api/v1/subscribe/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          subscribe: true
        })
      }).then(function(res: Response){
        return res.json();
      }).then(() => {
        this.setState({isSubscribe: true});
      });
    } else {
      console.log('subscribe > DELETE');
      fetch('http://localhost:3001/api/v1/subscribe/', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      }).then(function(res: Response){
        return res;
      }).then(() => {
        this.setState({isSubscribe: false});
      });
    }
    console.log('변경: isSubscribe = ' + isSubscribe);
  }

  render () {
    const { isSubscribe } = this.state;
    return (
      <div>
        {!isSubscribe ?
        <div>
          <p>응모 하시겠습니까?</p>
          <button onClick={this.toggleState}>응모 하기</button>
        </div>
        :
        <div>
          <p>응모 하셨습니다(감사합니다)</p>
          <button onClick={this.toggleState}>응모 취소(정말?)</button>
        </div>
        }
      </div>
    );
  }

  componentDidMount() {
    console.log('subscribe > GET');
    fetch('http://localhost:3001/api/v1/subscribe/').then(function(res: Response){
      return res.json();
    }).then((json) => {
      if (json.length) {
        this.setState({isSubscribe: true});
      }
    });
  }
}

const Api = () => (
  <div>
    <h3>Api</h3>
    <Body />
  </div>
);

export default Api;
