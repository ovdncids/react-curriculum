import * as React from 'react';

interface State {
  isSubscribe: boolean;
}

class Body extends React.Component<{}, State> {
  constructor() {
    super();
    const subscribe = JSON.parse(String(localStorage.getItem('subscribe')));
    this.state = {
      isSubscribe: !!subscribe
    };
    console.log('현재: isSubscribe = ' + this.state.isSubscribe);
  }

  toggleState = () => {
    const { isSubscribe } = this.state;
    const subscribe = !isSubscribe;
    localStorage.setItem('subscribe', JSON.stringify(subscribe));
    this.setState({isSubscribe: subscribe});
    console.log('변경: isSubscribe = ' + isSubscribe);
  }

  render () {
    const { isSubscribe } = this.state;
    console.log(isSubscribe);
    return (
      <div>
        {!isSubscribe ?
        <div>
          <p>응모 하시겠습니까?</p>
          <button onClick={this.toggleState}>응모 하기</button>
        </div>
        :
        <div>
          <p>응모 하셨습니다(감사합니다)</p>
          <button onClick={this.toggleState}>응모 취소(정말?)</button>
        </div>

        }
      </div>
    );
  }
}

const LocalStorage = () => (
  <div>
    <h3>LocalStorage</h3>
    <Body />
  </div>
);

export default LocalStorage;
