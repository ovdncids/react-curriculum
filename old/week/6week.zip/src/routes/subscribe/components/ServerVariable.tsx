import * as React from 'react';

interface State {
  isSubscribe: boolean;
}

class Body extends React.Component<{}, State> {
  constructor() {
    super();
    this.state = {
      isSubscribe: false
    };
  }

  toggleState = () => {
    console.log('subscribe > POST');
    const { isSubscribe } = this.state;
    const subscribe = !isSubscribe;
    fetch('http://localhost:3001/subscribe/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        subscribe: subscribe
      })
    }).then(function(res: Response){
      return res.json();
    }).then((json) => {
      this.setState({isSubscribe: json});
    });
    this.setState({isSubscribe: subscribe});
    console.log('변경: isSubscribe = ' + isSubscribe);
  }

  render () {
    const { isSubscribe } = this.state;
    return (
      <div>
        {!isSubscribe ?
        <div>
          <p>응모 하시겠습니까?</p>
          <button onClick={this.toggleState}>응모 하기</button>
        </div>
        :
        <div>
          <p>응모 하셨습니다(감사합니다)</p>
          <button onClick={this.toggleState}>응모 취소(정말?)</button>
        </div>

        }
      </div>
    );
  }

  componentDidMount() {
    console.log('subscribe > GET');
    fetch('http://localhost:3001/subscribe/').then(function(res: Response){
      return res.json();
    }).then((json) => {
      console.log(json);
      this.setState({isSubscribe: json});
    });
  }
}

const ServerVariable = () => (
  <div>
    <h3>ServerVariable</h3>
    <Body />
  </div>
);

export default ServerVariable;
