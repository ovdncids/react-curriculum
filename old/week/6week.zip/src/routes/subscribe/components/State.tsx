import * as React from 'react';

interface State {
  isSubscribe: boolean;
}

class Body extends React.Component<{}, State> {
  constructor() {
    super();
    this.state = {
      isSubscribe: false
    };
  }

  toggleState = () => {
    const { isSubscribe } = this.state;
    this.setState({isSubscribe: !isSubscribe});
    console.log(isSubscribe);
  }

  render () {
    const { isSubscribe } = this.state;
    console.log(isSubscribe);
    return (
      <div>
        {!isSubscribe ?
        <div>
          <p>응모 하시겠습니까?</p>
          <button onClick={this.toggleState}>응모 하기</button>
        </div>
        :
        <div>
          <p>응모 하셨습니다(감사합니다)</p>
          <button onClick={this.toggleState}>응모 취소(정말?)</button>
        </div>
        }
      </div>
    );
  }
}

const State = () => (
  <div>
    <h3>State</h3>
    <Body />
  </div>
);

export default State;
