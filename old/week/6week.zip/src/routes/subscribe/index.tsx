import * as React from 'react';
import { observer } from 'mobx-react';
import { Route, Link, RouteComponentProps } from 'react-router-dom';
import State from './components/State';
import SessionStorage from './components/SessionStorage';
import LocalStorage from './components/LocalStorage';
import ServerVariable from './components/ServerVariable';
import Api from './components/Api';
import i18n, { I18n } from '../../shared/stores/i18n';

interface Props {
  route?: RouteComponentProps<{}>;
}

@observer
class Router extends React.Component<Props, {}> {
  private i18n: I18n;

  constructor() {
    super();
    this.i18n = i18n;
  }

  render() {
    const { route } = this.props;
    const { t } = i18n;
    return (
      <div>
        <h2>{t('Subscribe')}</h2>
        <ul>
          <li><Link to={`${route.match.url}/state`}>state</Link></li>
          <li><Link to={`${route.match.url}/sessionStorage`}>sessionStorage</Link></li>
          <li><Link to={`${route.match.url}/localStorage`}>localStorage</Link></li>
          <li><Link to={`${route.match.url}/serverVariable`}>serverVariable</Link></li>
          <li><Link to={`${route.match.url}/api`}>api</Link></li>
        </ul>
        <hr />

        <Route path={`${route.match.url}/state`} component={State}/>
        <Route path={`${route.match.url}/sessionStorage`} component={SessionStorage}/>
        <Route path={`${route.match.url}/localStorage`} component={LocalStorage}/>
        <Route path={`${route.match.url}/serverVariable`} component={ServerVariable}/>
        <Route path={`${route.match.url}/api`} component={Api}/>
      </div>
    );
  }
}

const Subscribe = (props: RouteComponentProps<{}>) => (
  <Router route={props}/>
);

export default Subscribe;
